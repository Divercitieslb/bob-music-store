/* Bob Music Store — theme behaviour.
   Small, dependency-free, progressive: every interaction here has a working
   no-JS fallback (real links, real form submits).

   Two rules that shape the structure:

   1. Per-section wiring lives in initSection(root) and is re-run on
      shopify:section:load. The theme editor destroys and re-inserts a
      section's DOM on every settings change, so anything bound once at parse
      time goes dead the first time a merchant edits that section.
   2. Anything that hides content is done HERE, never in Liquid. The markup
      ships visible so a visitor with JS off loses nothing; JS adds the hidden
      state only once it has taken over the behaviour. */
(function () {
  'use strict';

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* ------------------------------------------------------------ drawers -- */
  var lastFocus = null;
  var lastOpener = null;

  function openDrawer(id, opener) {
    var d = document.getElementById(id);
    if (!d) return;
    lastFocus = document.activeElement;
    lastOpener = opener || null;
    d.classList.add('is-open');
    d.setAttribute('aria-hidden', 'false');
    if (lastOpener) lastOpener.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
    var f = d.querySelector('input,button,a[href]');
    if (f) setTimeout(function () { f.focus(); }, 60);
  }

  function closeDrawer(d) {
    if (!d) return;
    d.classList.remove('is-open');
    d.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    // reset every trigger for this drawer, not just the one that opened it
    $$('[data-open="' + d.id + '"]').forEach(function (b) {
      b.setAttribute('aria-expanded', 'false');
    });
    lastOpener = null;
    if (lastFocus) { lastFocus.focus(); lastFocus = null; }
  }

  document.addEventListener('click', function (e) {
    var opener = e.target.closest('[data-open]');
    if (opener) {
      var id = opener.getAttribute('data-open');
      // the cart icon is a real link; only intercept when the drawer exists
      if (document.getElementById(id)) { e.preventDefault(); openDrawer(id, opener); }
      return;
    }
    var closer = e.target.closest('[data-close]');
    if (closer) { e.preventDefault(); closeDrawer(closer.closest('.drawer')); }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    var open = $('.drawer.is-open');
    if (open) closeDrawer(open);
  });

  // keep focus inside an open drawer
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Tab') return;
    var d = $('.drawer.is-open');
    if (!d) return;
    var f = $$('a[href],button:not([disabled]),input,select,textarea,[tabindex]:not([tabindex="-1"])', d)
      .filter(function (el) { return el.offsetParent !== null; });
    if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });

  /* ------------------------------------------------------------ quantity -- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-qty],[data-cart-qty]');
    if (!b) return;
    var step = parseInt(b.getAttribute('data-qty') || b.getAttribute('data-cart-qty'), 10);
    var input = b.parentNode.querySelector('input');
    if (!input) return;
    var min = parseInt(input.getAttribute('min') || '0', 10);
    input.value = Math.max(min, (parseInt(input.value, 10) || 0) + step);
    input.dispatchEvent(new Event('change', { bubbles: true }));
  });

  /* ------------------------------------------------- per-section wiring --- */
  var searchCtrl = null;

  function initTabs(root) {
    $$('[data-tabs]', root).forEach(function (wrap) {
      if (wrap.dataset.tabsReady) return;
      wrap.dataset.tabsReady = '1';

      var tabs = $$('[data-tab]', wrap);
      var panels = $$('[data-panel]', wrap);
      if (tabs.length < 2 || !panels.length) return;

      // Non-first panels ship with the hidden attribute; base.css restores
      // them when <html> has no .js class. Setting .hidden here is enough —
      // it was already correct, what was missing was a CSS rule that outranks
      // the UA stylesheet, since .grid{display:grid} beat it.
      function select(i) {
        tabs.forEach(function (t, j) {
          t.setAttribute('aria-selected', String(i === j));
          t.tabIndex = i === j ? 0 : -1;
        });
        panels.forEach(function (p, j) { p.hidden = i !== j; });
      }
      select(0);

      tabs.forEach(function (tab, i) {
        tab.addEventListener('click', function () { select(i); });
        tab.addEventListener('keydown', function (e) {
          var d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
          if (!d) return;
          e.preventDefault();
          var n = (i + d + tabs.length) % tabs.length;
          tabs[n].focus();
          select(n);
        });
      });
    });
  }

  function initGallery(root) {
    var main = $('[data-gallery-main]', root);
    if (!main || main.dataset.galleryReady) return;
    main.dataset.galleryReady = '1';
    var thumbs = $$('[data-gallery-thumb]', root);
    thumbs.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var img = main.querySelector('img');
        if (!img) return;
        var full = btn.getAttribute('data-full');
        if (full) { img.src = full; img.removeAttribute('srcset'); }
        img.alt = btn.getAttribute('data-alt') || '';
        thumbs.forEach(function (b) { b.setAttribute('aria-current', String(b === btn)); });
      });
    });
  }

  function initCart(root) {
    $$('[data-cart-input]', root).forEach(function (input) {
      if (input.dataset.cartReady) return;
      input.dataset.cartReady = '1';
      input.addEventListener('change', function () {
        var form = input.closest('form');
        if (!form) return;
        // submit through the update button so Shopify does not read this as a
        // checkout click (the checkout button is the form's default submitter)
        var upd = form.querySelector('[name="update"]');
        if (upd) { upd.click(); } else { form.submit(); }
      });
    });
  }

  function initSort(root) {
    var sort = $('[data-sort]', root);
    if (!sort || sort.dataset.sortReady) return;
    sort.dataset.sortReady = '1';
    sort.addEventListener('change', function () {
      var u = new URL(window.location.href);
      u.searchParams.set('sort_by', sort.value);
      u.searchParams.delete('page');
      window.location.href = u.toString();
    });
  }

  function initFacets(root) {
    var form = $('[data-facet-form]', root);
    if (!form || form.dataset.facetReady) return;
    form.dataset.facetReady = '1';
    form.addEventListener('change', function () {
      var u = new URL(window.location.href);
      Array.from(u.searchParams.keys()).forEach(function (k) {
        if (k.indexOf('filter.') === 0) u.searchParams.delete(k);
      });
      $$('input', form).forEach(function (el) {
        if (el.type === 'checkbox' && el.checked) u.searchParams.append(el.name, el.value);
        if (el.type === 'number' && el.value) u.searchParams.set(el.name, el.value);
      });
      u.searchParams.delete('page');
      window.location.href = u.toString();
    });
  }

  function initSearch(root) {
    var sInput = $('[data-search-input]', root);
    var sOut = $('[data-search-results]', root);
    if (!sInput || !sOut || sInput.dataset.searchReady) return;
    if (!window.Shop || !window.Shop.routes || !window.Shop.routes.predictive) return;
    sInput.dataset.searchReady = '1';

    var t = null;
    sInput.addEventListener('input', function () {
      clearTimeout(t);
      var q = sInput.value.trim();
      if (q.length < 2) {
        if (searchCtrl) { searchCtrl.abort(); searchCtrl = null; }
        sOut.innerHTML = '';
        sInput.setAttribute('aria-expanded', 'false');
        return;
      }
      t = setTimeout(function () {
        // abort the in-flight request so a slow early reply cannot overwrite
        // a fast later one
        if (searchCtrl) searchCtrl.abort();
        searchCtrl = new AbortController();
        var url = window.Shop.routes.predictive +
          '?q=' + encodeURIComponent(q) +
          '&resources[type]=product&resources[limit]=6&section_id=predictive-search';
        fetch(url, { signal: searchCtrl.signal })
          .then(function (r) { return r.ok ? r.text() : Promise.reject(r.status); })
          .then(function (html) {
            var doc = new DOMParser().parseFromString(html, 'text/html');
            var grid = doc.querySelector('[data-predictive-grid]');
            sOut.innerHTML = grid ? grid.innerHTML : '';
            sInput.setAttribute('aria-expanded', sOut.innerHTML ? 'true' : 'false');
          })
          .catch(function (err) {
            if (err && err.name === 'AbortError') return;
            sOut.innerHTML = '';
          });
      }, 220);
    });
  }

  /* ------------------------------------------------------------ mega menu --
     The nav wraps onto two rows, and the panel opens below BOTH of them. So
     travelling from a first-row trigger down to its own panel drags the pointer
     straight across the second row — every item it brushes past used to steal
     the panel on the way, and the swap between them is the flinch.

     Hover alone cannot express "I am on my way to the panel". This can: opening
     is delayed, and the delay is much longer when a panel is already open than
     when none is, so a pass-through never wins but resting on an item still
     does. Reaching the open panel cancels the pending switch outright.

     Closing is on a grace timer and only when the pointer leaves the whole nav.
     The panel is a DOM descendant of .nav, so moving into it never fires the
     leave at all — which is what removes the flinch.

     CSS keeps :focus-within untouched for keyboard use, and keeps the plain
     :hover rules alive under html:not(.js), so with JS off the menu behaves
     exactly as it did.
     ---------------------------------------------------------------------- */
  var megaWired = false;

  function initMega() {
    if (megaWired) return;
    var nav = $('.header__nav .nav');
    if (!nav) return;

    var items = $$('.nav__item', nav).filter(function (li) {
      return li.querySelector('.mega');
    });
    if (!items.length) return;
    megaWired = true;

    // Resting on an item opens it. Brushing past one on the way to an open
    // panel does not: 260ms is longer than a deliberate downward sweep spends
    // over any single row-two item, and shorter than an intent to stop.
    var OPEN = 90, SWITCH = 260, CLOSE = 200;
    var fine = window.matchMedia('(hover:hover) and (pointer:fine)');
    var open = null, timer = null;

    function clear() { if (timer) { clearTimeout(timer); timer = null; } }

    function show(li) {
      clear();
      if (open === li) return;
      if (open) open.classList.remove('is-open');
      open = li;
      if (li) li.classList.add('is-open');
    }

    function hide() {
      clear();
      if (open) { open.classList.remove('is-open'); open = null; }
    }

    function mouse(e) {
      // pointerenter also fires for touch, where a tap is a navigation and an
      // opened panel would sit under the finger.
      return fine.matches && (!e.pointerType || e.pointerType === 'mouse');
    }

    items.forEach(function (li) {
      li.addEventListener('pointerenter', function (e) {
        if (!mouse(e)) return;
        clear();
        if (open === li) return;
        timer = setTimeout(function () { show(li); }, open ? SWITCH : OPEN);
      });

      li.querySelector('.mega').addEventListener('pointerenter', function (e) {
        // Arrived at the panel — whatever the pointer crossed to get here does
        // not get to take it.
        if (mouse(e) && open === li) clear();
      });
    });

    nav.addEventListener('pointerenter', clear);
    nav.addEventListener('pointerleave', function (e) {
      if (!mouse(e)) return;
      clear();
      timer = setTimeout(hide, CLOSE);
    });

    // A click is a navigation; leave nothing hanging over the new page during
    // the request, and give Escape the usual way out.
    nav.addEventListener('click', function (e) {
      if (e.target.closest && e.target.closest('a')) hide();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' || e.key === 'Esc') hide();
    });
  }

  function initSection(root) {
    initTabs(root);
    initGallery(root);
    initCart(root);
    initSort(root);
    initFacets(root);
    initSearch(root);
  }

  /* ----------------------------------------------------- header height ---- */
  /* Condense-on-scroll and the progress rail belong to sections/header.liquid,
     which owns its own listener. All that is needed here is the true header
     height: --header-h is the sticky offset for .pdp__info and for
     scroll-margin, and the real header is the announcement bar plus the logo
     row plus the nav row — around 186px on desktop, not the 82px placeholder
     in :root. Measure it rather than guess. */
  var header = $('[data-header]');

  function publishHeaderHeight() {
    if (!header) return;
    document.documentElement.style.setProperty('--header-h', header.offsetHeight + 'px');
  }

  /* ---------------------------------------------------------------- boot -- */
  function boot() {
    initSection(document);
    initMega();
    publishHeaderHeight();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.addEventListener('resize', publishHeaderHeight, { passive: true });

  // the theme editor replaces a section's DOM wholesale on every edit
  document.addEventListener('shopify:section:load', function (e) {
    initSection(e.target);
    // the header is a section too, and the editor replaces its DOM wholesale
    megaWired = false;
    initMega();
    publishHeaderHeight();
  });
  document.addEventListener('shopify:section:unload', function () {
    if (searchCtrl) { searchCtrl.abort(); searchCtrl = null; }
  });
})();
